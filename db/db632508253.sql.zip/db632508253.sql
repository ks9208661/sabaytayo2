-- phpMyAdmin SQL Dump
-- version 4.1.14.8
-- http://www.phpmyadmin.net
--
-- Host: db632508253.db.1and1.com
-- Generation Time: Sep 17, 2016 at 10:48 AM
-- Server version: 5.5.50-0+deb7u2-log
-- PHP Version: 5.4.45-0+deb7u4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db632508253`
--

-- --------------------------------------------------------

--
-- Table structure for table `st_boat_operators`
--

CREATE TABLE IF NOT EXISTS `st_boat_operators` (
  `port` varchar(8) COLLATE latin1_general_ci NOT NULL,
  `mobile_number` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `operator_name` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `boat_name` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `capacity` smallint(6) NOT NULL,
  `last_update` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `st_member_mobiles`
--

CREATE TABLE IF NOT EXISTS `st_member_mobiles` (
  `subscriber_number` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `access_token` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `activation_timestamp` int(11) NOT NULL,
  `current` tinyint(1) NOT NULL,
  PRIMARY KEY (`subscriber_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `st_member_mobiles`
--

INSERT INTO `st_member_mobiles` (`subscriber_number`, `access_token`, `activation_timestamp`, `current`) VALUES
('+639053442312', 'YWydqrPdTyn9aRh8a1kNzoDf_XPuRchQPoALvp7FJwQ', 1474104131, 1),
('+639178555658', 'vW8BnxB-bcXL0do6a8e_jmUE0xapyAykELurTq575x8', 1474104406, 1),
('+639273958863', 'IC6j4xdxP-IYqlXY6e7wniw9Q0D_8HJlA4RMnWN5ipA', 1474114640, 1);

-- --------------------------------------------------------

--
-- Table structure for table `st_ports`
--

CREATE TABLE IF NOT EXISTS `st_ports` (
  `code` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `latitude` decimal(9,6) NOT NULL,
  `longitude` decimal(9,6) NOT NULL,
  PRIMARY KEY (`code`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `st_ports`
--

INSERT INTO `st_ports` (`code`, `name`, `latitude`, `longitude`) VALUES
('PHMDRPIN', 'Pinamalayan, Mindoro', '13.031758', '121.491480'),
('PHROMSBL', 'Sibale, Romblon', '12.912654', '121.720324'),
('PHROMSBL', 'Concepcion, Romblon', '12.912654', '121.720324');

-- --------------------------------------------------------

--
-- Table structure for table `st_trips`
--

CREATE TABLE IF NOT EXISTS `st_trips` (
  `subscriber_number` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `port_orig` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `port_dest` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `dept_date` date NOT NULL DEFAULT '0000-00-00',
  `dept_time` time DEFAULT NULL,
  `pax` tinyint(4) NOT NULL,
  `notes` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `timezone` varchar(6) COLLATE latin1_general_ci DEFAULT NULL,
  `dept_timestamp` int(11) DEFAULT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`subscriber_number`,`port_orig`,`port_dest`,`dept_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `st_trips`
--

INSERT INTO `st_trips` (`subscriber_number`, `port_orig`, `port_dest`, `dept_date`, `dept_time`, `pax`, `notes`, `timezone`, `dept_timestamp`, `timestamp`) VALUES
('+639178555658', 'PHSBL', 'PHPIN', '2016-09-19', '11:30:00', 3, 'may dalang 10 banig', '+08:00', 1474255800, 1474102488),
('+639273958863', 'PHSBL', 'PHPIN', '2016-09-19', '11:30:00', 3, 'may bata', '+08:00', 1474255800, 1474114877),
('+639053442312', 'PHSBL', 'PHPIN', '2016-09-19', '15:30:00', 2, 'mamimili', '+08:00', 1474270200, 1474115450);

-- --------------------------------------------------------

--
-- Table structure for table `st_weather`
--

CREATE TABLE IF NOT EXISTS `st_weather` (
  `pk` int(11) NOT NULL AUTO_INCREMENT,
  `port` varchar(8) COLLATE latin1_general_ci NOT NULL,
  `temp_current` tinyint(4) NOT NULL,
  `temp_forecast` tinyint(4) NOT NULL,
  `windspeed_current` smallint(6) NOT NULL,
  `windspeed_forecast` smallint(6) NOT NULL,
  `direction_current` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `direction_forecast` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `chance_rain_current` tinyint(4) NOT NULL,
  `chance_rain_forecast` tinyint(4) NOT NULL,
  `gale_warning` tinyint(1) DEFAULT NULL,
  `last_update` int(11) NOT NULL,
  PRIMARY KEY (`pk`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `st_weather`
--

INSERT INTO `st_weather` (`pk`, `port`, `temp_current`, `temp_forecast`, `windspeed_current`, `windspeed_forecast`, `direction_current`, `direction_forecast`, `chance_rain_current`, `chance_rain_forecast`, `gale_warning`, `last_update`) VALUES
(1, 'PHMDRPIN', 29, 31, 85, 79, 'NE', 'E', 30, 30, 1, 1474123582),
(2, 'PHROMSBL', 28, 29, 12, 17, 'E', 'E', 30, 30, 0, 1474123582),
(5, 'PHROMSMR', 30, 31, 14, 15, 'NE', 'NE', 25, 25, 0, 1474123582),
(6, 'PHROMBNT', 30, 29, 18, 19, 'NE', 'E', 15, 25, 0, 1474123582);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
